import './NoData.css'


export default function NoData( ) {
    return (
        <div className='NoData'>
            No Data
        </div>
    )
}
