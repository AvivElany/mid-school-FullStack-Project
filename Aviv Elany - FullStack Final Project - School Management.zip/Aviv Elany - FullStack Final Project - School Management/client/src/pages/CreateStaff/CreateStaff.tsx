import './CreateStaff.css'

/*interface ICreateStaffProps {

}*/
export default function CreateStaff(/*props: ICreateStaffProps*/) {
    return (
        <div className='CreateStaff'>
            CreateStaff
        </div>
    )
}
