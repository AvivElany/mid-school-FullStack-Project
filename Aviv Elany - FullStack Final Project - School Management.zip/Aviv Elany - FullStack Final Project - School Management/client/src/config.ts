
export const appName:string = 'school-menagement'
export const developer:string = 'Aviv Elany'
export const lecturer:string = 'Elran Amrussi'
export const classYear:number = 2024

// ---------------------------------------------------------------------------------------------------------

export const apiBase: string = 'http://127.0.0.1:3000'
